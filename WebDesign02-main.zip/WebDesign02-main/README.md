# WebDesign02
This repo contains a practiced problem for you to applying CSS and different selectors
